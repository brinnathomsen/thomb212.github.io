var angryphrases = [
  generateAngryPhrase1(),
  generateAngryPhrase2(),
  generateAngryPhrase3()
];

$(".greeting").html(generateHappyGreeting());
$(".greeting").html(generateAngryGreeting());


function generateAngryGreeting() {
  var intro = [
    "Oh...hi.",
    "Oh, it's you",
    "Umm, can I help you?",
  ];

  var angry_greeting = "";
  angry_greeting = sample(intro);

  return angry_greeting;
}


function generateHappyGreeting() {

  var intro = [
    "Hi there!",
    "Hey hun!",
    "Well hello!",
    "Happy to see you!",
  ];

  var happy_greeting = "";
  happy_greeting = sample(intro);

  $(".greeting").css("font-weight", "900");
  $(".greeting").css("font-style", "italic");

  return happy_greeting;
}



function generateAngryPhrase1() {
  var verb = [
    "realize",
    "learn",
    "see",
    "show",
    "remember",
  ];

  var phrase = [
    "you appreciate and rely on me",
    "you understand that you are not the center of the universe",
    "you mistreat me",
    "I have feelings, you know"
  ];

  var angry_phrase1 = "";
  angry_phrase1 = "You need to " + sample(verb) + " that " + sample(phrase) +
    ". ";

  // $(".rant").css("font-weight", "900");
  // $(".rant").css("font-style", "italic");
  // $(".rant").css("line-height", "25px");

  return angry_phrase1;
}


function generateAngryPhrase2() {
  var place = [
    "place",
    "planet",
    "city",
    "earth",
    "life",
    "land",
    "world"
  ];


  var angry_phrase2 = "";
  angry_phrase2 = "I wish you would just leave this " + sample(place) +
    ". ";


  return angry_phrase2;
}

function generateAngryPhrase3() {
  var frequency = [
    "only",
    "sometimes",
    "really",
    "always",
    "often",
    "also"
  ];

  var ability = [
    "think",
    "write",
    "make anything",
    "read",
    "spell",
    "run",
    "walk",
    "grow",
    "hear",
    "eat",
    "talk"
  ];

  var angry_phrase3 = "";
  angry_phrase3 = "Honestly I " + sample(frequency) +
    " wish you would lose your ability to " + sample(ability) +
    ". It would do the world a favor.";

  return angry_phrase3;
}


function sample(a) {
  return a[Math.floor(Math.random() * a.length)];
}


var phraseNumber = 1;

var lock_to_bottom = setInterval(move, 1000);
var repeat_phrase = setInterval(add_phrase, 2000);

function add_phrase() {
  phraseNumber++;
  var newPhrase = "<span class='rant" + phraseNumber + "'>" + sample(
    angryphrases) + "</span>";
  $(".rant").append(newPhrase);
}


// AUTO SCROLL TO BOTTOM
function move() {
  $("html,body").animate({
    scrollTop: $(document).height()
  }, 0);
}

// BREAK AUTO SCROLL AND SET BACK WHEN SCROLLED TO BOTTOM
$(window).scroll(function() {
  clearInterval(lock_to_bottom);

  var window_height = $(window).height(),
    doc_height = $(document).height(),
    scroll_pos = $(window).scrollTop();

  if ((scroll_pos + window_height) >= (doc_height - 100)) {
    lock_to_bottom = setInterval(function() {
      move();
    }, 100);
  }
});



var fontWeight;
var fontSize = 10;
var lineHeight = 10;

var secondsInactive = 0;
var lastInteraction = new Date().getTime();


$("html").mousemove(function(event) {
  secondsInactive = 0;

  var currTime = new Date().getTime();
  var timeSinceUsed = ((currTime - lastInteraction));
  lastInteraction = new Date().getTime();

});

var mouseInactive = setInterval(function() {
  changeLineHeight();
  // changeFontSize();
  changeFontWeight();

  secondsInactive++;
}, 500);



function changeFontWeight() {

  if (secondsInactive < 2) {
    fontWeight = 100;
  }
  if (secondsInactive >= 2 && secondsInactive < 4) {
    fontWeight = 200;
  }
  if (secondsInactive >= 4 && secondsInactive < 6) {
    fontWeight = 300;
  }
  if (secondsInactive >= 6 && secondsInactive < 8) {
    fontWeight = 400;
  }
  if (secondsInactive >= 8 && secondsInactive < 10) {
    fontWeight = 500;
  }
  if (secondsInactive >= 10 && secondsInactive < 12) {
    fontWeight = 600;
    $(".rant" + phraseNumber).css("font-style", "italic");
  }
  if (secondsInactive >= 12 && secondsInactive < 14) {
    fontWeight = 700;
    $(".rant" + phraseNumber).css("font-style", "italic");
  }
  if (secondsInactive >= 14 && secondsInactive < 16) {
    fontWeight = 800;
    $(".rant" + phraseNumber).css("font-style", "italic");
  }
  if (secondsInactive >= 16) {
    fontWeight = 900;
    $(".rant" + phraseNumber).css("font-style", "italic");
    $(".rant" + phraseNumber).css("text-transform", "uppercase");
  }


  $(".rant" + phraseNumber).css("font-weight", fontWeight);
}

function changeLineHeight() {
  if (secondsInactive > 0) {
    lineHeight = 1;
  }

  if (secondsInactive >= 10 && secondsInactive < 20) {
    lineHeight = 0.5;
  }



  $(".rant" + phraseNumber).css("line-height", lineHeight);
}

function changeFontSize() {
  // FONT SIZE
  if (secondsInactive >= 0) {
    fontSize = fontSize + 2;
  }
  if (fontSize > 40) {
    fontSize = 30;
  }

  $(".rant" + phraseNumber).css("font-size", fontSize);
}
